var app1 = angular.module("app",[]);
app1.controller('mainCtrl',function($scope){
  $scope.curPage = 0;
  $scope.pageSize = 3;
  $scope.json = [{"year":"2001","Theft over $500":32222,"Theft under":60352},
  {"year":"2002","Theft over $500":27367,"Theft under":46378},
  {"year":"2003","Theft over $500":20394,"Theft under":36387},
  {"year":"2004","Theft over $500":19020,"Theft under":35270},
  {"year":"2005","Theft over $500":18648,"Theft under":27378},
  {"year":"2006","Theft over $500":20506,"Theft under":26706},
  {"year":"2007","Theft over $500":21852,"Theft under":24756},
  {"year":"2008","Theft over $500":23825,"Theft under":24876},
  {"year":"2009","Theft over $500":21134,"Theft under":23732},
  {"year":"2010","Theft over $500":21432,"Theft under":24071},
  {"year":"2011","Theft over $500":15283,"Theft under":28329},
  {"year":"2012","Theft over $500":15599,"Theft under":28767},
  {"year":"2013","Theft over $500":15259,"Theft under":27118},
  {"year":"2014","Theft over $500":14521,"Theft under":28173},
  {"year":"2015","Theft over $500":12390,"Theft under":24193},
  {"year":"2016","Theft over $500":3486,"Theft under":5925}];

  $scope.numberOfPages = function() {
     return Math.ceil($scope.json.length / $scope.pageSize);
   };
  $scope.theft_drop = "Theft over $500";
  $scope.year_drop = "2001";
});



angular.module('app1').filter('pagination', function()
{
 return function(input, start)
 {
  start = +start;
  return input.slice(start);
 };
});
