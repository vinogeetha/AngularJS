var myapp = angular.module('sampleapp', [ ]);

myapp.controller('samplecontoller', function ($scope,$window) {


  $scope.arr=[];
  $scope.arr1=[];
  $scope.theft_drop = "Theft over $500";
   $scope.curPage = 0;
   $scope.pageSize = 3;
  $scope.year_drop="2001";
$scope.a = "";
     $scope.datalists = [{"year":"2001","Theft over $500":32222,"Theft under":60352},
     {"year":"2002","Theft over $500":27367,"Theft under":46378},
     {"year":"2003","Theft over $500":20394,"Theft under":36387},
     {"year":"2004","Theft over $500":19020,"Theft under":35270},
     {"year":"2005","Theft over $500":18648,"Theft under":27378},
     {"year":"2006","Theft over $500":20506,"Theft under":26706},
     {"year":"2007","Theft over $500":21852,"Theft under":24756},
     {"year":"2008","Theft over $500":23825,"Theft under":24876},
     {"year":"2009","Theft over $500":21134,"Theft under":23732},
     {"year":"2010","Theft over $500":21432,"Theft under":24071},
     {"year":"2011","Theft over $500":15283,"Theft under":28329},
     {"year":"2012","Theft over $500":15599,"Theft under":28767},
     {"year":"2013","Theft over $500":15259,"Theft under":27118},
     {"year":"2014","Theft over $500":14521,"Theft under":28173},
     {"year":"2015","Theft over $500":12390,"Theft under":24193},
     {"year":"2016","Theft over $500":3486,"Theft under":5925}];


     for(x=0;x<$scope.datalists.length;x++){
       $scope.arr1[x]=$scope.datalists[x].year;
     }
     $scope.d= $scope.datalists;
     $scope.d = $scope.datalists;
     $scope.search = function(){

      $scope.yr=$scope.year_drop;
      for(j=0;j<$scope.d.length;j++)
       { $scope.data = [];

       if($scope.yr == $scope.arr1[j] ){

       $scope.data.push($scope.d[j])
       $scope.datalists = $scope.data;
         console.log($scope.datalists[j]);
     }
    }
  };


      $scope.sort_asc = function(var1){
        $scope.datalists.sort(function(a,b){
          return (b[var1]-a[var1]);
        })
      };
      $scope.sort_desc = function(var1){
        $scope.datalists.sort(function(a,b){
          return (a[var1]-b[var1]);
        })
      };

$scope.add_record = function(texty,texto,textu){
for(j=0;j<$scope.datalists.length;j++){

  $scope.datalists.push({"year":texty,"Theft over $500":texto,"Theft under":textu});
  console.log($scope.datalists.length);
  $scope.numberOfPages =  Math.ceil($scope.datalists.length / $scope.pageSize);
  for(i=1;i<=$scope.numberOfPages;i++){
    $scope.arr[i-1]=i;
  }
}
};
$scope.update_record = function(year,texto,textu){
for(j=0;j<$scope.datalists.length;j++){
  if($scope.datalists[j].year==year){
    $scope.datalists[j]['Theft over $500'] = texto;
    $scope.datalists[j]['Theft under'] = textu;
    $window.alert("Updated Successfully !!");
  }
  }

};

$scope.delete_record = function(year){
$scope.arr =[];
for(j=0;j<$scope.datalists.length;j++){
  if($scope.datalists[j].year==year){
    $scope.datalists = $scope.datalists.slice(j+1);

  }
}console.log($scope.datalists);
console.log($scope.datalists.length);
$scope.numberOfPages =  Math.ceil($scope.datalists.length / $scope.pageSize);
for(i=1;i<=$scope.numberOfPages;i++){
  $scope.arr[i-1]=i;
}
console.log($scope.numberOfPages);
};


  $scope.IsVisible = false;
              $scope.edit_record = function (year) {
                console.log(year);
                  $scope.yr_unedit = year;
                  $scope.IsVisible = $scope.IsVisible ? false : true;
                }
                $scope.IsAddVisible = false;
                            $scope.add_record_toggle = function () {

                                $scope.IsAddVisible = $scope.IsAddVisible ? false : true;
                              }

$scope.numberOfPages =  Math.ceil($scope.datalists.length / $scope.pageSize);
for(i=1;i<=$scope.numberOfPages;i++){
  $scope.arr[i-1]=i;
}
$scope.value_search = function(theft,txt){
$scope.data1 =[];
$scope.arr = [];
console.log(txt);
        for(j=0;j<$scope.datalists.length;j++)
         {
           if(theft=="Theft over $500"){
             if($scope.datalists[j]['Theft over $500'] > txt){
               console.log("hiiii");
               $scope.data1.push($scope.datalists[j]);
           }
         }
           else{
             if($scope.datalists[j]['Theft under'] > txt){
               $scope.data1.push($scope.datalists[j]);
           }
           }

       }$scope.datalists = $scope.data1;
       console.log($scope.datalists);
       $scope.numberOfPages =  Math.ceil($scope.datalists.length / $scope.pageSize);
       for(i=1;i<=$scope.numberOfPages;i++){
         $scope.arr[i-1]=i;
       }
       console.log($scope.numberOfPages);

};



});

angular.module('sampleapp').filter('pagination', function()
{
 return function(input, start)
 {
  start = +start;
  return input.slice(start);
 };

});
myapp.directive('addDirective',function(){
  return {
    templateUrl : 'add.html'
  };
});
myapp.directive('tableDirective',function(){
  return {
    templateUrl : 'table.html'
  };
});
myapp.directive('pageDirective',function(){
  return {
    templateUrl : 'page.html'
  };
});
